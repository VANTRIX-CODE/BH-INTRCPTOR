import csv
import json
import os

input_sql = 'parameter.sql'
output_json = 'data/parameters.json'

parameters = []

print(f"Lese {input_sql}...")

# Stelle sicher, dass der data-Ordner existiert
os.makedirs('data', exist_ok=True)

with open(input_sql, 'r', encoding='utf-8', errors='ignore') as file:
    for line in file:
        line = line.strip()
        
        # HeidiSQL exportiert die Wertezeilen im Format: (1, NULL, ...), oder am Ende (491, ...);
        if line.startswith('(') and (line.endswith('),') or line.endswith(');')):
            # Wir schneiden die vordere Klammer "(" und das "),"/");" am Ende ab
            clean_line = line[1:-2]
            
            # Ein SQL-Insert verhält sich exakt wie eine CSV-Datei (Kommagetrennt).
            # Wir nutzen den Python CSV-Reader. Er schützt uns davor, dass Kommas 
            # INNERHALB von Texten (z.B. bei 'Heizkurve, Soll') das Skript sprengen.
            reader = csv.reader([clean_line], quotechar="'", skipinitialspace=True)
            
            for row in reader:
                try:
                    # Index in der Tabelle (aus deinem Dump):
                    # 0: param_id, 1: DOM_ID, 2: DOM_TYP, 3: ACTIVE, 4: AVERAGE, 
                    # 5: ID, 6: NR, 7: TYP, 8: NAME
                    
                    param_id = int(row[0])
                    active = int(row[3]) if row[3] != 'NULL' else 0
                    id_str = row[5]
                    nr = int(row[6]) if row[6] != 'NULL' else 0
                    typ = row[7]
                    name = row[8].strip() # Leerzeichen am Rand entfernen
                    
                    parameters.append({
                        "param_id": param_id,
                        "ACTIVE": active,
                        "ID": id_str,
                        "NR": nr,
                        "TYP": typ,
                        "NAME": name
                    })
                except Exception as e:
                    print(f"Warnung: Überspringe eine fehlerhafte Zeile: {e}")

# Die gesammelten Daten als formatierte JSON-Datei speichern
with open(output_json, 'w', encoding='utf-8') as outfile:
    json.dump(parameters, outfile, indent=4, ensure_ascii=False)

print(f"Erfolgreich! {len(parameters)} Parameter wurden nach '{output_json}' konvertiert.")